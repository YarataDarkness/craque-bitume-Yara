# index.html
## Carroussel
### Images du carroussel


# 2nouvelles.html (news-hub)
## Carte de nouvelles (CPT)
### Image
### Nom
### Description
### Date
## Héros
### Image
### Titre

# detailnouvelles.html (news-article)
## Description de nouvelles (CPT)
### Image
### Nom
### Description
### Date
### Type
### Prix
### Stock
### Heure
### Lieu
### Formateur

# 3services.html (service)
## Carte de services (CPT)
### Image
### Nom
### Description
### Date
## Héros
### Image
### Titre

# detailservices.html (service-hub)
## Description de services (CPT)
### Image
### Nom
### Description
### Type
### Prix
## Héros
### Image
### Titre

# 4equipe.html (team)
## Membre de l'équipe (CPT)
### Nom
### Poste
### Image
## Modale (CPT)
### Titre
### Image
### Paragraphe d'informations
## Héros
### Image
### Titre

# 5histoire.html (history)
## Héros
### Image
### Titre

# 6propos.html (about)
## Héros
### Image
### Titre

# erreur404.html (404)
